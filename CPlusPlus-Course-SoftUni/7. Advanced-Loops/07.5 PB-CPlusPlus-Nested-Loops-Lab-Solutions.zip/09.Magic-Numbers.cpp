#include <iostream>

using namespace std;

int main(){

    int n;
    cin >> n;
    
    int endIndex;
    
    if(n < 9){
       endIndex = n;
    }else{
        endIndex = 9;
    }

    for(int a = 1; a <= endIndex; a++){
        for(int b = 1; b <= endIndex; b++){
            for(int c = 1; c <= endIndex; c++){
                for(int d = 1; d <= endIndex; d++){
                    for(int e = 1; e <= endIndex; e++){
                        for(int f = 1; f <= endIndex; f++){
                             int value = a * b * c * d * e * f;
                             if(value == n){
                                cout << a << b << c
                                    << d << e << f << " ";
                             }
                        }
                    }
                }
            }
        }
    }

    return 0;
}
