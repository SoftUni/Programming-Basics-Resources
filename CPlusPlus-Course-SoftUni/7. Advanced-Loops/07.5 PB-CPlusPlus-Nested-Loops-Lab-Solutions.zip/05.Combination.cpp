#include <iostream>
#include <cmath>

using namespace std;

int main(){

    int number;

    cin >> number;

    int counter = 0;

    for(int a = 0; a <= number; a++){
        for(int b = 0; b <= number; b++){
            for(int c = 0; c <= number; c++){
                for(int d = 0; d <= number; d++){
                    for(int e = 0; e <= number; e++){
                        if(a + b + c + d + e == number){
                            counter++;
                        }
                    }
                }
            }
        }
    }

    cout << counter << endl;

    return 0;
}
