#include <iostream>
#include <string>

using namespace std;

int main(){

    int n;

    cin >> n;

    for(int i = 1; i <= n; i++){
        string in;

        cin >> in;
        bool flour = false, eggs = false, sugar = false;
        while(in != "Bake!" || !flour || !eggs || !sugar){
            if(in == "flour"){
                flour = true;
            }else if(in == "eggs"){
                eggs = true;
            }else if(in == "sugar"){
                sugar = true;
            }

            if(in == "Bake!" && (!flour || !eggs || !sugar)){
                cout << "The batter should contain flour, " <<
                  "eggs and sugar!" << endl;
            }

            cin >> in;
        }

        cout << "Baking batch number " << i << "..." << endl;

    }

    return 0;
}
