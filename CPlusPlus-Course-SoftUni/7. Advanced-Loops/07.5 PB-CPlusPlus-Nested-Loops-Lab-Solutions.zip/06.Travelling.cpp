#include <iostream>
#include <string>

using namespace std;

int main(){

    string destination;

    getline(cin, destination);

   while(destination != "End"){

        double cost;

        cin >> cost;

        while(cost > 0){
            double savings{};
            cin >> savings;
            cost -= savings;
        }

        cout << "Going to " << destination << "!" << endl;

        cin.ignore();
        
        getline(cin, destination);
   }

    return 0;
}
