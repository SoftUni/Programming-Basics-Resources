#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int n;
    cin >> n;

    int number = 0;

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            if(number <= n)
            {
                number = i + j - 1;
            }
            if(number > n)
            {
                number = 2 * n - number;
            }
            cout << number << " ";
        }
        cout << endl;
    }

    return 0;
}
