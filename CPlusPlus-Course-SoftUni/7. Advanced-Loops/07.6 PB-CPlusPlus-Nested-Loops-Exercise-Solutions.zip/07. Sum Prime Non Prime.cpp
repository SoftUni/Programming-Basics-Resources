#include <iostream>
#include <string>
#include<math.h>

using namespace std;

int main()
{
    string input;
    getline(cin, input);

    int sumPrimeNumbers = 0;
    int sumNonPrimeNumbers = 0;


    while(input != "stop" &&  input != "STOP")
    {
        int n = stoi(input);
        if(n < 0)
        {
            cout << "Number is negative." << endl;
        }
        else if(n == 1)
        {
            sumNonPrimeNumbers += n;
        }
        else if(n == 2)
        {
            sumPrimeNumbers += n;
        }
        else
        {
            bool isPrime = true;
            int num = sqrt(n);
            for(int i = 2; i <= num ; i++)
            {
                if(n % i == 0)
                {
                    isPrime = false;
                    break;
                }
            }
            if(isPrime)
            {
                sumPrimeNumbers += n;
            }
            else
            {
                sumNonPrimeNumbers += n;
            }
        }

        getline(cin, input);
    }

    cout << "Sum of all prime numbers is: " << sumPrimeNumbers << endl;
    cout << "Sum of all non prime numbers is: " << sumNonPrimeNumbers << endl;


    return 0;
}
