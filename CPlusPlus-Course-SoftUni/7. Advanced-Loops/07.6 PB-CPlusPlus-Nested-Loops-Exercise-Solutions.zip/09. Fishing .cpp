#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int main()
{
	int dailyQuota;
	cin >> dailyQuota;

	cin.ignore();
	double sum = 0;
	int counter = 0;
	for (int i = 1; i <= dailyQuota; i++)
	{
		string fishName;
		getline(cin, fishName);

		if (fishName == "Stop")
		{
			goto Outer;
		}

		double fishKilos;
		cin >> fishKilos;

		double price = 0;

		for (int i = 0; i < fishName.length(); i++)
		{
			price += (char)fishName[i];
		}
		price /= fishKilos;

		if (i % 3 == 0)
		{
			sum += price;
		}
		else
		{
			sum -= price;
		}
		counter++;
		cin.ignore();
	}

	cout << "Lyubo fulfilled the quota!" << endl;

Outer:
	cout.setf(ios::fixed);
	cout.precision(2);
	if (sum < 0)
	{
		cout << "Lyubo lost " << abs(sum) << " leva today." << endl;
	}
	else
	{
		cout << "Lyubo\'s profit from " << counter << " fishes is " << sum << " leva." << endl;
	}
	return 0;
}
