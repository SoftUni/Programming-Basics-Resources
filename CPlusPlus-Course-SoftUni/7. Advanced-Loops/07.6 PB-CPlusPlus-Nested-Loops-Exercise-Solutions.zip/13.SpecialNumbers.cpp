#include<iostream>
using namespace std;

int main()
{
    int n;
    cin >> n;

    for (int first = 1 ; first <= 9 ; first++){
        for(int second = 1; second <= 9 ; second++){
            for(int third = 1; third <= 9 ; third++){
                for (int forth = 1; forth <= 9; forth++){

                    bool check1 = n % first == 0;
                    bool check2 = n % second == 0;
                    bool check3 = n % third == 0;
                    bool check4 = n % forth == 0;

                    if(check1 && check2 && check3 && check4){
                        cout << first << second << third << forth << " ";
                    }


                }
            }
        }
    }

    return 0;
}
