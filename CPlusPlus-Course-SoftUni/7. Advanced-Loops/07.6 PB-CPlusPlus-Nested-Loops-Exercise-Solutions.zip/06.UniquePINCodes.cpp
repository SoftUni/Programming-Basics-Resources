#include<iostream>
using namespace std;

int main()
{
    int endFirst, endSecond, endThird;
    cin >> endFirst >> endSecond >> endThird;

    for(int i = 1; i <= endFirst; i++)
    {
        for (int j = 1; j <= endSecond; j++)
        {
            for (int k = 1; k <= endThird; k ++)
            {
                bool isPrime = true;
                for(int a = 2; a <= j / 2; a++)
                {
                    if(j % a == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }

                if(j >= 2 && j <= 7 && i % 2 == 0 && k % 2 == 0  && isPrime)
                {
                    cout << i << " " << j << " " << k << endl;

                }

            }
        }
    }

    return 0;
}
