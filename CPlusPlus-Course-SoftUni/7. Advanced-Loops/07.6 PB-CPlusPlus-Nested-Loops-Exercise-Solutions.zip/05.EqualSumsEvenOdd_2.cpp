#include <iostream>
using namespace std;

int main() {
    int number1, number2;
    cin >> number1 >> number2;

    int sum1 = 0, sum2 = 0;
    int numCount = 0;

    for (int i = number1; i <= number2; i++) {

        int num1 = i % 10;
        int num2 = i / 10 % 10;
        int num3 = i / 100 % 10;
        int num4 = i / 1000 % 10;
        int num5 = i / 10000 % 10;
        int num6 = i / 100000 % 10;

        sum1 = num1 + num3 + num5;
        sum2 = num2 + num4 + num6;

        if (sum1 == sum2) {
            cout << i << " ";
            numCount++;
        }

        sum1 = 0;
        sum2 = 0;
    }
    return 0;
}
