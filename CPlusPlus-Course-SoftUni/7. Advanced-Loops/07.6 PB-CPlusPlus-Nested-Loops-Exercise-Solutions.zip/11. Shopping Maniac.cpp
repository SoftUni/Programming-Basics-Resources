#include <iostream>
#include <string>


using namespace std;

int main()
{
	int amount;
	cin >> amount;

	int clothesCounter = 0;
	int sumSpents = 0;

	if (amount == 0)
	{
		cout << "For " << clothesCounter << " clothes I spent " << sumSpents << " lv and have " << amount - sumSpents << " lv left." << endl;
		return 0;
	}
	while (true)
	{
		string action;
		cin >> action;

		if (action == "enough")
		{
			break;
		}
		if (action == "enter")
		{
			while (true)
			{
				string clothesPrice;
				cin >> clothesPrice;
				if (clothesPrice == "leave")
				{
					break;
				}
				else if (!clothesPrice.find_first_not_of("0123456789"))
				{
					cin.ignore();
					continue;
				}
				else
				{
					sumSpents += stoi(clothesPrice);
				}

				if (amount - sumSpents > 0)
				{
					clothesCounter++;
				}
				else if (amount- sumSpents == 0)
				{
					clothesCounter++;
					cout << "For " << clothesCounter << " clothes I spent " << sumSpents << " lv and have " << amount - sumSpents << " lv left." << endl;
					return 0;
				}
				else if(amount - sumSpents < 0)
				{
					cout << "Not enough money." << endl;
					sumSpents -= stoi(clothesPrice);
				}
			}
		}
		else
		{
			cin.ignore();
			continue;
		}

	}
	cout << "For " << clothesCounter << " clothes I spent " << sumSpents << " lv and have " << amount - sumSpents << " lv left." << endl;
	return 0;
}
