#include<iostream>
using namespace std;

int main()
{
    int n,l;
    cin >> n >> l;

    for (int first = 1 ; first <= n ; first++){
        for(int second = 1; second <= n ; second++){
            for(int third = 'a'; third < 'a' + l ; third++){
                for(int forth = 'a'; forth < 'a' + l; forth++){
                    for(int fifth = 1; fifth <= n; fifth++){

                            if(fifth > first && fifth > second){
                                cout << first << second << (char)third << (char)forth << fifth << " ";
                            }
                    }
                }
            }
        }
    }
    return 0;
}
