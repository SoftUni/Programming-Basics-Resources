#include <iostream>
#include <string>
using namespace std;

int main() {
    int numJury;
    cin >> numJury;
    cin.ignore();
    string nameOfPresentation;
    getline(cin, nameOfPresentation);

    double grade = 0;
    double sumGrades = 0;
    double averageGrade = 0;
    int counter = 0;

    cout.setf(ios::fixed);
    cout.precision(2);

    while (nameOfPresentation != "Finish") {
        for (int i = 0; i < numJury; i++) {
            cin >> grade;
            sumGrades += grade;
            if (i == numJury - 1) {
                cout << nameOfPresentation << " - " << sumGrades / numJury << "." << endl;
                counter++;
            }
        }
        cin.ignore();
        averageGrade += sumGrades / numJury;
        getline(cin, nameOfPresentation);
        sumGrades = 0;
    }

    cout << "Student's final assessment is " << averageGrade / counter << "." << endl;

    return 0;
}
