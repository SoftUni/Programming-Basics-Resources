#include <iostream>

using namespace std;

int main(){
    int a;
    cin>> a;

    int rowCounter = 1;
    int counter = 1;

    while(true){
        for(int i = 1; i <= rowCounter; i++){
            cout << counter << " ";
            counter++;
            if(counter > a){
                break;
            }
        }
        cout << endl;
        if(counter > a){
            break;
        }
        rowCounter++;
    }
    return 0;
}
