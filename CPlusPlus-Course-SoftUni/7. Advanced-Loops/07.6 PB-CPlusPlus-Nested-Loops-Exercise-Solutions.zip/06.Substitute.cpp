#include<iostream>
using namespace std;

int main()
{
    int k, l, m, n;
    cin >> k >> l >> m >> n;

    int counter = 0;


    for (int first1 = k ; first1 <= 8 ; first1++)
    {
        for(int second1 = 9; second1 >= l ; second1--)
        {
            for(int first2 = m; first2 <= 8 ; first2++)
            {
                for(int second2 = 9; second2 >= n ; second2--)
                {
                    /// ������� ����� �� �: first1 � second1
                    ///������� ����� �� �: first2 � second2

                    bool check1 = first1 % 2 == 0 && first2 % 2 == 0;
                    bool check2 = second2 % 2 == 1 && second1 % 2 == 1;

                    if (check1 && check2)
                    {

                        if(first1 != first2 || second1 != second2)
                        {
                            cout << first1 << second1 << " - " << first2 << second2 << endl;
                            counter++;
                        }
                        else
                        {
                            cout << "Cannot change the same player." << endl;
                        }
                        if(counter == 6)
                        {
                           return 0;
                        }


                    }
                }
            }
        }
    }
    return 0;

}
