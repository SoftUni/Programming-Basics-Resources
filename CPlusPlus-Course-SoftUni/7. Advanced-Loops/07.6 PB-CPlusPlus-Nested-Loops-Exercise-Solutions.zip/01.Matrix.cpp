#include <iostream>

using namespace std;

int main()
{
	int a, b, c, d;
	cin >> a >> b >> c >> d;

	for (int first = a; first <= b; first++)
	{
		for (int second = a; second <= b; second++)
		{
			for (int third = c; third <= d; third++)
			{
				for (int four = c; four <= d; four++)
				{
					if (first != second && third != four)
					{
						if (first + four == second + third)
						{
							cout << first << second << endl;
							cout << third << four << endl;
							cout << endl;
						}
					}
				}
			}
		}
	}
	return 0;
}
