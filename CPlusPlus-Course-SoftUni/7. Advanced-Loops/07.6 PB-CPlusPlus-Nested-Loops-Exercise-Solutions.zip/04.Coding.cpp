#include <iostream>
#include <string>

using namespace std;

int main()
{
    int n;
    cin >> n;

    string number = to_string(n);
    int rows = number.size();

    for(int i = 0; i < rows; i++)
    {
        for(int j = 0; j <= number.size() - 1; j++)
        {
            while(n > 0)
            {
                int digit = n % 10;
                n /= 10;
                char symbol = digit + 33;

                if(digit == 0)
                {
                    cout << "ZERO";
                }
                for(int k = 0; k < digit; k++)
                {
                    cout << symbol;
                }
                cout << endl;
            }
        }
    }
    return 0;
}
