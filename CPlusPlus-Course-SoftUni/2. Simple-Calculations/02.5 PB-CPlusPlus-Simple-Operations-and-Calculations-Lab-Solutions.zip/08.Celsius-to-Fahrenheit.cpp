#include <iostream>

using namespace std;

int main(){

    double celsius;

	//Read input
    cin >> celsius;

	//Calculate celsius value
    celsius = celsius * 1.8 + 32;

	//Print output
    cout << celsius << endl;

    return 0;
}
