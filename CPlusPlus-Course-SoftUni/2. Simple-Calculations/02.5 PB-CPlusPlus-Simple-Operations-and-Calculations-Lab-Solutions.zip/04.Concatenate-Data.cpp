#include <iostream>
#include <string>

using namespace std;

int main(){
	
	//Declare proper data types and try to order them in the same order as the input
	string firstName, lastName;
	
	int age;
	
	string town;
	
	//Read input in the specific order
	cin >> firstName >> lastName >> age >> town;
	
	//Print the output by chaining each required value by using plain text and the variables in your program
	cout << "You are " << firstName << " " << lastName << ", a " << age << "-years old person from " << town << "." << endl;
	
	return 0;
}