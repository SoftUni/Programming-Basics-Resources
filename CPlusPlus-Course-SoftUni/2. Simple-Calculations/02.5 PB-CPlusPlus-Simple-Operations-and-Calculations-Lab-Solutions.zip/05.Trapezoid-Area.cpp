#include <iostream>

using namespace std;

int main(){

	//Choose proper data types
    double b1, b2, h;

	//Read input
    cin >> b1 >> b2 >> h;

	//Calculate area
    double area = (b1 + b2) * h / 2.0;

	//Print output
    cout << area << endl;

    return 0;
}
