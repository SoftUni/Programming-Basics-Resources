#include <iostream>
#include <cmath>
//#include <iomanip>

using namespace std;

int main(){

    double side, height;
	
	//Read input
    cin >> side >> height;

	//Calculate area
    double area = side * height / 2;

	//Print and format the output
	//Note this functionality requires #include <iomanip> - library
	//The first possible way for formatting the output is commended since we only want to print it once
    //cout  << fixed << setprecision(2) << area << endl;
	
	//Or we can use this way without additiona library
	
	
	//Both ways of formatting the output will set fixed precision to print floating point values
	cout.setf(ios::fixed);
    cout.precision(2);
	
	//Print the output
    cout << area << endl;

    return 0;
}
