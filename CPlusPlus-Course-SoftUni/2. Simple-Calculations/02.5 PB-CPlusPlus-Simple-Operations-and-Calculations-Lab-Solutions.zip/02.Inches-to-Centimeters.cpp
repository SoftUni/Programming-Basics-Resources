#include <iostream>

using namespace std;

int main(){

    double inches;
	
	//Read input
    cin >> inches;

	//Calculate centimeters
    double cm = inches * 2.54;

	//Print output
    cout << cm << endl;

    return 0;
}
