#include <iostream>
#include <cmath>

using namespace std;

int main(){

    double radians;

	//Read input
    cin >> radians;

	//Calculate degrees from radians (find the formula on the internet)
    double degrees = 180 / 3.14159265359 * radians;

	//Use round function to round the floating point value to integer value
	//NOTE: the round function is only available whe you include the cmath header -> #include <cmath>
    degrees = round(degrees);

	//Print the output
    cout << degrees << endl;

	return 0;
}
