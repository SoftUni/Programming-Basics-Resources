#include <iostream>
#include <cmath>
using namespace std;

int main(){

    double radius;

	//Read input
    cin >> radius;

	//Set proper value for PI
    double pi = 3.14159265359;
	
	//Calculate area
    double area = pi * radius * radius;

	//Calculate perimeter
    double perimeter = 2 * pi * radius;

	//Print output
    cout << "Area = " << area << endl;
    cout <<  "Perimeter = " << perimeter << endl;

    return 0;
}
