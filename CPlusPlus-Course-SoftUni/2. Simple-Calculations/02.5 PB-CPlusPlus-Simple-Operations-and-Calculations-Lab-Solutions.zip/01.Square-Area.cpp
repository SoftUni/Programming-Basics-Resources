#include <iostream>

using namespace std;

int main(){

    int sideA;
	
	//Read input
    cin >> sideA;
	
	//Calculate area
    int area = sideA * sideA;

	//Print output
    cout << area << endl;

    return 0;
}