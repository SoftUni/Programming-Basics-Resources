#include <iostream>
#include <cmath>

using namespace std;

int main(){
	
	//Determine proper data types and declare variables
    int length, width, height;

    double percent;

	//Read input: Make sure you read all the input in the porper order
    cin >> length >> width >> height >> percent;

	//Calculate volum
    int volume = length * width * height;

	//Calculate liters by given formula in task description
    double liters = volume * 0.001;

	//Remove the percentage of other objects inside the aquarium
    liters = liters - liters * percent / 100;

	//Format the output to three digits after the decimal point
    cout.setf(ios::fixed);
    cout.precision(3);
	
	//Print the output
    cout << liters << endl;

    return 0;
}
