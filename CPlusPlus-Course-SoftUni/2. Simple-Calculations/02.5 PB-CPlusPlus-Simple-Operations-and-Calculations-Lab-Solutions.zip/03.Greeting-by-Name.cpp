#include <iostream>

using namespace std;

int main(){

    string name;

	//Read input
    cin >> name;

	//Print output
    cout << " Hello, ";
    cout << name << "! " << endl;


    return 0;
}
