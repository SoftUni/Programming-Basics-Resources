#include <iostream>
#include <cmath>
using namespace std;

int main ()
{
    int sectors, capacity;
    double price;
    cin >> sectors >> capacity >> price;

    double pricePerSector = (capacity * price) / sectors;
    double total = capacity * price;

    double priceCharity = (total - (0.75 * pricePerSector))/8;

    cout.setf(ios :: fixed);
    cout.precision(2);

    cout << "Total income - " << total << " BGN" << endl;
    cout << "Money for charity - " << priceCharity << " BGN" << endl;


    return 0;
}
