#include <iostream>
#include <cmath>
using namespace std;

int main()
{

    double lenght, width, wardrobeSide;
    cin >> lenght >> width >> wardrobeSide;

    double hall = lenght * 100 * width * 100;
    double wardrobe = wardrobeSide * wardrobeSide * 100 * 100;
    double bench = hall / 10;
    double freeSpace = hall - wardrobe - bench;
    int dancers = floor(freeSpace / 7040);

    cout << dancers << endl;

    return 0;
}
