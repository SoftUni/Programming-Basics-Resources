#include <iostream>
#include <cmath>
using namespace std;

int main ()
{
    int days, bakers, cakes, waffles, pancakes;
    cin >> days >> bakers >> cakes >> waffles >> pancakes;

    double priceCakes = cakes * 45;
    double priceWaffles = waffles * 5.80;
    double pricePancakes = pancakes * 3.20;

    double sumPerDay = (priceCakes + priceWaffles + pricePancakes) * bakers;
    double sumPerCampaign = sumPerDay * days;
    double finalSum = sumPerCampaign - sumPerCampaign / 8;

     cout.setf(ios :: fixed);
     cout.precision(2);

     cout << finalSum << endl;
    return 0;
}
