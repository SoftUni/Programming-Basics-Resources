#include <iostream>
#include <cmath>
using namespace std;

int main ()
{

    double priceWhiskey, beer, wine, rakia, whiskey;
    cin >> priceWhiskey >> beer >> wine >> rakia >> whiskey;

    double priceRakia = priceWhiskey / 2;
    double priceWine = priceRakia - 0.4 * priceRakia;
    double priceBeer = priceRakia - 0.8 * priceRakia;

    double sumRakia = rakia * priceRakia;
    double sumWine = wine * priceWine;
    double sumBeer = beer * priceBeer;
    double sumWhiskey = whiskey * priceWhiskey;

    double total = sumRakia + sumWine + sumBeer + sumWhiskey;

    cout.setf(ios :: fixed);
    cout.precision(2);

    cout << total << endl;

    return 0;
}
