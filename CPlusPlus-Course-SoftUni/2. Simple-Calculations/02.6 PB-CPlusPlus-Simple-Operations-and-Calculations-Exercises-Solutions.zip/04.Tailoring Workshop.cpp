#include <iostream>
using namespace std;

int main(){

        int tables;
        cin >> tables;
        double lenght, width;
        cin >> lenght;
        cin >> width;

        double covers = tables * (lenght + 2 * 0.30) * (width + 2 * 0.3);
        double squares = tables * (lenght / 2) * (lenght / 2);
        double priceDollars = covers * 7 + squares * 9;

        cout.setf(ios::fixed);
        cout.precision(2);

        cout << priceDollars << " USD" << endl;
        cout << priceDollars * 1.85 << " BGN" << endl;

return 0;
}
