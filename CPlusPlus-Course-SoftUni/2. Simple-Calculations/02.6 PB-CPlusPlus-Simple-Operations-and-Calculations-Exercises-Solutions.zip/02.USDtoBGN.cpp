#include <iostream>
#include <iomanip>
using namespace std;

int main () {
    double dollars;
    cin >> dollars;
    double bgn = dollars * 1.79549;
    cout << fixed << setprecision(2)<< bgn << " BGN" << endl;
return 0;
}
