#include<iostream>
using namespace std;
int main()
{
    int hours, minutes;
    cin >> hours >> minutes;

    int all = hours * 60 + minutes + 15;

    int hours1 = all / 60;
    int minutes1 = all % 60;

    if (hours1 >= 24)
    {
        hours1 -= 24;
    }
        if(minutes1 < 10){
    cout << hours1 << ":0" <<minutes1<<endl;}
    else {
         cout << hours1 << ":" <<minutes1<<endl;
    }




    return 0;
}
