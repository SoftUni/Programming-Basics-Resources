#include <iostream>
#include <cmath>
using namespace std;

int main()
{
   int steps, dancers, days;
   cin >> steps >> dancers >> days;

   double stepsPerDay = ceil(((steps / days * 1.0) / steps) * 100);
   double percentPerDancer = stepsPerDay / dancers;

      cout.setf(ios :: fixed);
      cout.precision(2);

   if(stepsPerDay <= 13){
    cout << "Yes, they will succeed in that goal! " << percentPerDancer << "%." << endl;
   }else {

       cout << "No, They will not succeed in that goal! Required " << percentPerDancer << "% steps to be learned per day." << endl;
   }


    return 0;
}
