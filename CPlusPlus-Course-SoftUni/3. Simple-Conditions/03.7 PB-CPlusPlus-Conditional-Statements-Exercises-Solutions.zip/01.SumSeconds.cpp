#include <iostream>

using namespace std;

int main()
{
    int sec1, sec2, sec3;
    cin >> sec1 >> sec2 >> sec3;

    int totalSeconds = sec1 + sec2 + sec3;

    int minutes = totalSeconds / 60;
    int seconds = totalSeconds % 60;

    if(seconds < 10){
        cout << minutes << ":0" << seconds;
    }else {
        cout << minutes << ":" << seconds;
    }


    return 0;
}
