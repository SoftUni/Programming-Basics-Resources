#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    double record, distance, timePerMeter;
    cin >> record >> distance >> timePerMeter;

    double swimmingTime = distance * timePerMeter;
    double slowness = floor((distance / 15)) * 12.5;

    double totalTime = swimmingTime + slowness;
    cout.setf(ios::fixed);
    cout.precision(2);

    if(record > totalTime) {
            cout << "Yes, he succeeded! The new world record is " << totalTime << " seconds." << endl;

    }else {

        cout << "No, he failed! He was " << totalTime - record << " seconds slower." << endl;
    }




    return 0;
}
