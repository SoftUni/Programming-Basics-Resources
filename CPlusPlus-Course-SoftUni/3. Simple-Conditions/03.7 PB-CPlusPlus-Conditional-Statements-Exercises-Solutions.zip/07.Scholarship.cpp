#include <iostream>
using namespace std;
int main()
{

    double income, grade, minimumSalary;

    cin >> income >> grade >> minimumSalary;

    if(grade <= 4.5 || (grade >= 4.5 && grade <= 5.5 && income > minimumSalary))
    {
        cout << "You cannot get a scholarship!" << std::endl;
    }
    else
    {
        double social = minimumSalary * 0.35;
        double ace = grade * 25;
        cout.setf(ios::fixed);
        cout.precision(0);
        if(grade <= 5.5)
        {
            cout << "You get a Social scholarship " << social << " BGN" << endl;
        }
        else if(social > ace && income < minimumSalary)
        {
            cout << "You get a Social scholarship " << social << " BGN" << endl;
        }
        else
        {
            cout << "You get a scholarship for excellent results " << ace << " BGN" << endl;
        }
    }
    return 0;
}
/* #include<iostream>
#include<cmath>
using namespace std;
int main()
{
    double record, distance, timePerMeter;
    cin >> record >> distance >> timePerMeter;

    double swimmingTime = distance * timePerMeter;
    double slowness = floor((distance / 15)) * 12.5;

    double totalTime = swimmingTime + slowness;
    cout.setf(ios::fixed);
    cout.precision(2);

    if(record > totalTime) {
            cout << "Yes, he succeeded! The new world record is " << totalTime << " seconds." << endl;

    }else {

        cout << "No, he failed! He was " << totalTime - record << " seconds slower." << endl;
    }




    return 0;
} */



