#include <iostream>

using namespace std;

int main()
{
    int num;
    cin >> num;

    double bonusPoints = 0;

    if(num <= 100)
    {
        bonusPoints = 5;
    }
    else if (num > 1000)
    {
        bonusPoints = 0.1 * num;
    }
    else if (num > 100 )
    {
        bonusPoints = 0.2 * num;
    }

    if(num % 2 == 0)
    {
        bonusPoints = bonusPoints + 1; // bonusPoints += 1;
    }
    else if (num % 10 == 5)
    {
        bonusPoints += 2;
    }

    cout << bonusPoints << endl;
    cout << bonusPoints + num << endl;


    return 0;
}
