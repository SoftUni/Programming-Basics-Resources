#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double time1, time2, time3, timeFishing;
    cin >> time1 >> time2 >> time3 >> timeFishing;

    double totalTime = 1 / (1/time1 + 1/time2 + 1/time3);
    double cleaningTime = totalTime + 0.15 * totalTime; // 1.15 * totalTime



    cout.setf(ios :: fixed);
    cout.precision(2);
    cout << "Cleaning time: " << cleaningTime << endl;
    cout.precision(0);
    if(timeFishing >= cleaningTime)
    {
        double left = timeFishing - cleaningTime;
        cout << "Yes, there is a surprise - time left -> " << floor(left) << " hours." << endl;

    }
    else
    {
        double need = cleaningTime - timeFishing;
        cout << "No, there isn't a surprise - shortage of time -> " << ceil (need) << " hours." << endl;
    }


    return 0;
}
