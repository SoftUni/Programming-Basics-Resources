#include <iostream>

using namespace std;

int main(){

    int number;
	
	//Read the input number
    cin >> number;

	//Here we use the ability to structure the chaining of conditional statements
	//First we check for number lower than 100
    if(number < 100){
       cout << "Less than 100" << endl;
    }
	//Then we check for number greater than 200 
	else if(number > 200){
       cout << "Greater than 200" << endl;
    }
	//Therefore we will only execute the else statement if the number is between [100 and 200]
	else{
       cout << "Between 100 and 200" << endl;
    }
	
	//Once again do some test with your own values to see how it works

    return 0;
}