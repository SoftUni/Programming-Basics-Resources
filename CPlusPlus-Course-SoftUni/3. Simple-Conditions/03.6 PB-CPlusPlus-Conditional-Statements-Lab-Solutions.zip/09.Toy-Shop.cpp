#include <iostream>

using namespace std;

int main(){

    //Determine data types needed according to the task's description
    double price;

    int puzzleCount, dollsCount, tedyCount, minionsCount, trucksCount;

	//Read the input
	//Remember it is relly important to read the input in the order specified in the task's description
    cin >> price >> puzzleCount >> dollsCount >> tedyCount >> minionsCount >> trucksCount;

    //Calculate the profit
    double profit = puzzleCount * 2.60 + dollsCount * 3 + tedyCount * 4.10 +
                    minionsCount * 8.20 + trucksCount * 2;


    //Calculate total toys count
    int toysCount = puzzleCount + dollsCount + tedyCount + minionsCount + trucksCount;

    //Check for discount
    if(toysCount >= 50){
		//if there is discount we decreace the profit by 25%
		//this will be executed only if the total count of toys is greater or equal to 50
        profit = profit * 0.75;
    }

    //Pay for Rent - we decreace the profit with 10%
    profit = profit * 0.90;

    //We set fixed format for floating point values and precision of 2
    cout.setf(ios::fixed);
    cout.precision(2);

	//Check if profit is enough
    if(profit >= price){
		 //Print the output
         cout << "Yes! " << profit - price << " lv left." << endl;
    }else{
		//In case the profit wasn't enough we print the other possible output
        cout << "Not enough money! " << price - profit << " lv needed." << endl;
    }


    return 0;
}

