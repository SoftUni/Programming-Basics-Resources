#include <iostream>

using namespace std;

int main(){

    int number;

    cin >> number;

	//For this task we use chain of if - else - if - else statements
	//We do that because if we find a case where the number is equal to any of the valuse below
	//we do not want to do the rest of the conditional statements -> it is simply useless
	//Remember that if all of those contional statements are eluvated to false boolean value
	//only and only then the else conditional statement block will be executed
	
    if(number == 1){
        cout << "one" << endl;
    }else if(number == 2){
        cout << "two" << endl;
    }else if(number == 3){
        cout << "three" << endl;
    }else if(number == 4){
        cout << "four" << endl;
    }else if(number == 5){
        cout << "five" << endl;
    }else if(number == 6){
        cout << "six" << endl;
    }else if(number == 7){
        cout << "seven" << endl;
    }else if(number == 8){
        cout << "eight" << endl;
    }else if(number == 9){
        cout << "nine" << endl;
    }else{
        cout << "number too big" << endl;
    }
	
	//You can try to go throught the code step by step by using the Debugger
	//If you missed how we can use debugger in Code::Blocks
	//You can download the manual from the course page here: https://softuni.bg/trainings/2071/programming-basics-with-cpp-september-2018#lesson-9138
    //Try to do some test with different values and see what will happen

    return 0;
}
