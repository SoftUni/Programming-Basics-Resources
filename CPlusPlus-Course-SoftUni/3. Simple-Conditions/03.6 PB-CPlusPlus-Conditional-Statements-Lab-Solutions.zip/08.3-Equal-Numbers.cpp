#include <iostream>

using namespace std;

int main(){

    int firstNum, secondNum, thirdNum;

	//Read three numbers
    cin >> firstNum >> secondNum >> thirdNum;
    
	//Check if the first one is different from the second one
    if(firstNum != secondNum){
       cout << "no" << endl; 
    }
	//Check if the second one is different from the third one
	else if(secondNum != thirdNum){
        cout << "no" << endl;
    }
	//The only possible case we have to enter in the else block statement 
	//is if the three numbers are equal
	else{
        cout << "yes" << endl;
    } 

    return 0;
}