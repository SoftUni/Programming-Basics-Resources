#include <iostream>
#include <string>

using namespace std;

int main(){

    string inputPassword;
    
	//Read input password
    cin >> inputPassword;
    
	//Write in a variable of type string the real password
    string realPassword = "s3cr3t!P@ssw0rd";
    
	//Compare the two passwords
	//If they are equal the "Welcome" message will be printed
    if(inputPassword == realPassword){
        cout << "Welcome" << endl;
    }
	//If the passwords are not equal the "Wrong password!" will be printed
	else{
        cout << "Wrong password!" << endl;
    }

    return 0;
}
