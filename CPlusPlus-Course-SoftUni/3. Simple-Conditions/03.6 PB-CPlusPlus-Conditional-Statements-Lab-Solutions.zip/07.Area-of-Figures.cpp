#include <iostream>
#include <string>

using namespace std;

int main(){

    string figureType;

	//First read the figure type since we want to build different program behaviour
	//depending on the different figures (there are four possible types according to the task's description)
    cin >> figureType;
	
	//We set inital value of the area to zero (this is not required, however we can avoid undifined behaviour)
    double area = 0;

	//We create a sequence of conditional statements
    if(figureType == "square"){
	   //If the figure type is square we read a single number
       double side;
       cin >> side;
	   //Then we calculate and assign the current value for area
       area = side * side;
    }else if(figureType == "rectangle"){
       double sideA, sideB;
	   //If the figure type is rectangle we read a two numbers
       cin >> sideA >> sideB;
	   //Then we calculate and assign the current value for area
       area = sideA * sideB;
    }else if(figureType == "circle"){
       double radius;
	   //The figure type is circle so we read only the radius
       cin >> radius;
	   //Then we calculate and assign the current value for area
       area = 3.14159265359 * radius * radius;
    }else{
       double side, height;
	   //The last figure can only be triangle so we read two numbers
       cin >> side >> height;
	   //Then we calculate and assign the current value for area
       area = side * height / 2;
    }
	
	//We set fixed format for floating point values and precision of 3
    cout.setf(ios::fixed);
    cout.precision(3);
    
	//We print the output
    cout << area << endl;

    return 0;
}
