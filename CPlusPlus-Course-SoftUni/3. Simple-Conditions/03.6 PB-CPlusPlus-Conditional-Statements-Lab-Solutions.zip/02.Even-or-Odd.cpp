#include <iostream>

using namespace std;

int main(){

    int number;

    cin >> number;
	
	//Check if number divided modulo by two gives result equal to zero
	//If so the number is even
    if(number % 2 == 0){
        cout << "even" << endl;
    }
	//However if the upper statement is eluvated to false the else code block will be executed
	//And the result will be odd
	else{
        cout << "odd" << endl;
    }

    return 0;
}
