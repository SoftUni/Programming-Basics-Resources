#include <iostream>

using namespace std;

int main(){

    double grade;

    cin >> grade;

	//Contidional statement
    if(grade >= 5.50){
		//If grade is greater than or equal to 5.50 
		//The program will enter inside the conditional statement block and will print the message on the console
        cout << "Excellent!" << endl;
    }

    return 0;
}
