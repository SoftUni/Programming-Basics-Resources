#include <iostream>
#include <string>

using namespace std;

int main(){

    int firstNum, secondNum;

    cin >> firstNum >> secondNum;
	
	//Check if the first number is greater than the second
	//If so the program will execute only the if statement block
	//The output will be the first number
    if(firstNum > secondNum){
        cout << firstNum << endl;
    }
	//However if the upper statement is eluvated to false (the second number is greater or equal to the first one)
	//The else statement block will be executed
	//The output will be the second number
	else{
        cout << secondNum << endl;
    }

    return 0;
}
