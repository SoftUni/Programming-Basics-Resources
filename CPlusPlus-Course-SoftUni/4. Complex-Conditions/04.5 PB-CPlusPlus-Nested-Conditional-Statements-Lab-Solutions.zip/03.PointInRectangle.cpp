#include <iostream>
#include <string>

using namespace std;

int main(){

    double x1, y1, x2, y2, x, y;

	//Be sure to read the points coordinates in the right order
    cin >> x1 >> y1 >> x2 >> y2 >> x >> y;

	//We do the other way around check 
	//We want to see first if any of the points is outside of the rectangle
    if(x < x1 || x > x2 || y < y1 || y > y2){
       cout << "Outside" << endl;
    }else{
       cout << "Inside" << endl;
    }
	
	//TODO: try to reverse the check the other way around
	//Hint: there is code in the presentation

    return 0;
}
