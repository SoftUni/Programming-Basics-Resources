#include <iostream>
#include <string>

using namespace std;

int main(){

    string product, town;
    double quantity;
	
	//Read the input
    cin >> product >> town >> quantity;

	//Declare variable which value we will set in the correct case 
	//the right combination of town and product
    double price;

	//First condition is the town
    if(town == "Sofia"){
		//Then we check the product
       if(product == "coffee"){
          price = 0.5 * quantity;
       }else if(product == "water"){
           price = 0.8 * quantity;
       }else if(product == "beer"){
           price = 1.2 * quantity;
       }else if(product == "sweets"){
           price = 1.45 * quantity;
       }else{
             price = 1.6 * quantity;
       }
    }
	//We do the same for the rest of the cases
	//there is no need to check for invalid input
	else if(town == "Plovdiv"){
        if(product == "coffee"){
           price = 0.4 * quantity;
       }else if(product == "water"){
           price = 0.7 * quantity;
       }else if(product == "beer"){
           price = 1.15 * quantity;
       }else if(product == "sweets"){
           price = 1.3 * quantity;
       }else{
             price = 1.5 * quantity;
       }
    }else{
    if(product == "coffee"){
           price = 0.45 * quantity;
       }else if(product == "water"){
           price = 0.7 * quantity;
       }else if(product == "beer"){
           price = 1.1 * quantity;
       }else if(product == "sweets"){
           price = 1.35 * quantity;
       }else{
           price = 1.55 * quantity;
       }
    }
	
	//Print the calculated price
    cout << price << endl;

    return 0;
}
