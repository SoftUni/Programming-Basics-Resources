#include <iostream>
#include <string>

using namespace std;

int main(){

    string product;

    cin >> product;
	//We have multiple boolean expressions here 
	//We need only one of those conditions to be true
    if(product == "banana" || product == "apple"
        || product == "kiwi" || product == "cherry"
        || product == "lemon" || product == "grapes"){
         cout << "fruit" << endl;
    }
	//We do the same for the vegetables
	else if(product == "tomato" || product == "cucumber"
            || product == "pepper" || product == "carrot"){
        cout << "vegetable" << endl;
    }
	//If none of the upper is true we say that the type of the product is unknown
	//You can try with input "T4u6kA"
	else {
        cout << "unknown" << endl;
    }

    return 0;
}
