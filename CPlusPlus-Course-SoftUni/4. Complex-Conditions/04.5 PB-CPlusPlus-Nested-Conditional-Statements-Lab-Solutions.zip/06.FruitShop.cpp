#include <iostream>
#include <string>

using namespace std;

int main(){

    string product, day;
    double quantity;

	//Read the input
    cin >> product >> day >> quantity;

	//Since we will print the output each time we find a valid day and product
	//we have to set the correct format here
    cout.setf(ios::fixed);
    cout.precision(2);

	//First we check if it is working day
    if(day == "Monday" || day == "Tuesday"
        || day == "Wednesday" || day == "Thursday"
        || day == "Friday"){
		//We nest the checks for specific product inside the working days conditon
        if(product == "banana"){
            cout << 2.50 * quantity << endl;
        }else if(product == "apple"){
            cout << 1.20 * quantity << endl;
        }else if(product == "orange"){
            cout << 0.85 * quantity << endl;
        }else if(product == "grapefruit"){
            cout << 1.45 * quantity << endl;
        }else if(product == "kiwi"){
            cout << 2.70 * quantity << endl;
        }else if(product == "pineapple"){
            cout << 5.50 * quantity << endl;
        }else if(product == "grapes"){
            cout << 3.85 * quantity << endl;
        }
		//This statement will capture invalid product input but with valid working day
		else{
            cout << "error" << endl;
        }
    }
	//Then we check if it is weekend
	else if(day == "Saturday" || day == "Sunday"){
		//We do the same checks as for the working days
        if(product == "banana"){
            cout << 2.70 * quantity << endl;
        }else if(product == "apple"){
            cout << 1.25 * quantity << endl;
        }else if(product == "orange"){
            cout << 0.90 * quantity << endl;
        }else if(product == "grapefruit"){
            cout << 1.60 * quantity << endl;
        }else if(product == "kiwi"){
            cout << 3.00 * quantity << endl;
        }else if(product == "pineapple"){
            cout << 5.60 * quantity << endl;
        }else if(product == "grapes"){
            cout << 4.20 * quantity << endl;
        }else{
            cout << "error" << endl;
        }
    }
	//The last conditions will catch the invalid day input
	else{
        cout << "error" << endl;
    }
	
	//You can try to solve the problem with a variable which value is set each time a valid
	//day and product are included in the input

    return 0;
}
