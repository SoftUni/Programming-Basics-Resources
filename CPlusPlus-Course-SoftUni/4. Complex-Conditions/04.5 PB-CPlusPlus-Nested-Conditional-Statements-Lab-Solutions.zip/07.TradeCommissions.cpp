#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int main() {

	double sellValue;
	double commissionValue;

	string town;

	cin >> town >> sellValue;

	//We can declare a boolean value that will keep the validation of the input

    bool inputIsValid = true;

    //This time we can first check for invalid input and display error
    //if any we set the boolean value to false
	if (town != "Sofia" && town != "Varna" && town != "Plovdiv")	{
		cout << "error" << endl;
		inputIsValid = false;
	}
	else if (sellValue <= 0) {
		cout << "error" << endl;
		inputIsValid = false;
	}

	//Here we can check the town first
	if (town == "Sofia"){
        //Then we can check and calculate the commission value
		if (sellValue <= 500){
			commissionValue = sellValue * 0.05;
		}else if (sellValue <= 1000){
			commissionValue = sellValue * 0.07;
		}else if (sellValue <= 10000){
			commissionValue = sellValue * 0.08;
		}else {
			commissionValue = sellValue * 0.12;
		}
	}
	//We do the same for all other cases
	else if (town == "Varna") {
		if (sellValue <= 500) {
			commissionValue = sellValue * 0.045;
		}
		else if (sellValue <= 1000) {
			commissionValue = sellValue * 0.075;
		}
		else if (sellValue <= 10000) {
			commissionValue = sellValue * 0.10;
		}
		else {
			commissionValue = sellValue * 0.13;
		}
	}
	else {
		if (sellValue <= 500) {
			commissionValue = sellValue * 0.055;
		}
		else if (sellValue <= 1000) {
			commissionValue = sellValue * 0.08;
		}
		else if (sellValue <= 10000) {
			commissionValue = sellValue * 0.12;
		}
		else {
			commissionValue = sellValue * 0.145;
		}
	}

    //Again we need to format the output
    cout.setf(ios::fixed);
    cout.precision(2);

    //Here we will only print the value stored inside the commissionValue variable
    //if the input was valid
    //This is the so called boolean flag
    if(inputIsValid){
        cout << commissionValue << endl;
    }

    //However you can structure your conditional statements in right order
    //and with the correct checks so you won't have to use additional boolean variable
    //and without additional condition check whether you have to print the commission value or not
    //Try few different ways of solving the problem

	return 0;
}
