#include <iostream>
#include <string>

using namespace std;

int main(){
	
	
	//Read an integer which represents a day from the week
    int day;
    cin >> day;

	//Here we use the switch - case conditional construction
	//This is C++ so it will only work for integer values
	//char is also an integer value
	//There is also user defined variable type called Enumeration (hint: google it)
    switch(day){
	   //We set different cases note that 1 doesn't mean the number of the case
	   //but the value of the day variable
       case 1:
			//If we enter this case the following code will be executed
            cout << "Monday" << endl;
			//Never forget to break at the end of a case
			//if you don't the code will be executed like a waterfall
       break;
       case 2:
            cout << "Tuesday" << endl;
       break;
       case 3:
            cout << "Wednesday" << endl;
       break;
        case 4:
            cout << "Thursday" << endl;
       break;
       case 5:
            cout << "Friday" << endl;
       break;
       case 6:
            cout << "Saturday" << endl;
       break;
       case 7:
            cout << "Sunday" << endl;
       break;
	   //default case will be executed only if none of the upper is
       default:
            cout << "Error" << endl;
        break;
    }

    return 0;
}
