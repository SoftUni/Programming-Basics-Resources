#include <iostream>
#include <string>

using namespace std;

int main() {

	string animal;

	cin >> animal;

	//First case
	if (animal == "dog")	{
		cout << "mammal" << endl;
	}
	//Second case here we want to see if the animal is any of the following
	else if (animal == "crocodile" || animal == "tortoise" || animal == "snake")	{
		cout << "reptile" << endl;
	}
	//Any other case
	else {
		cout << "unknown" << endl;
	}
	
	return 0;
}