#include <iostream>
#include <string>

using namespace std;

int main(){

    int a;
    cin >> a;
	//The commented condition is the opposite in logical order
    ///if ((a >= 100 && a <= 200) || a == 0)
	//As you can see you can solve the problem both ways around
	//Try it
    if ((a < 100 || a > 200) && a != 0) {
        cout << "invalid" << endl;
    }

    return 0;
}