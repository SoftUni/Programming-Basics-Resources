#include <iostream>

using namespace std;

int main(){

    double age;
    char gender;

    cin >> age >> gender;

	//Chech the gender
    if(gender == 'f'){
		//Check the years
         if(age < 16){
            cout << "Miss" << endl;
         }else{
            cout << "Ms." << endl;
         }
    }
	//The second case if gender is not equal to 'f'
	else{
		//Check the years
         if(age < 16){
            cout << "Master" << endl;
         }else{
            cout << "Mr." << endl;
         }
    }

    return 0;
}
