#include <iostream>
#include <string>

using namespace std;

int main(){

	//Choose proper data types to store the input
    double budget;
    string category;
    int groupCount;

	//Read the input in the specific order
    cin >> budget >> category >> groupCount;

	//Note: Make sure to order the conditional statements in the right order
	//This way we don't need to check the lower values
	//What we do inside is to reduse the budget value by the transport cost
    if(groupCount <= 4){
        budget = budget - budget * 0.75;
    }else if(groupCount <= 9){
        budget = budget - budget * 0.60;
    }else if(groupCount <= 24){
        budget = budget / 2;
    }else if(groupCount <= 49){
        budget = budget - budget * 0.40;
    }else{
        budget = budget - budget * 0.25;
    }
	
	//Declare variable to store the ticket price
    double ticketsPrice;
	
	//Conditional statement to calculate the value 
    if(category == "VIP"){
        ticketsPrice = 499.99 * groupCount;
    }else{
        ticketsPrice = 249.99 * groupCount;
    }
	
	//Format the output
    cout.setf(ios::fixed);
    cout.precision(2);
	
	//Conditional statement to handle the two possible outputs
    if(budget >= ticketsPrice){
         cout << "Yes! You have " <<
         budget - ticketsPrice << " leva left." << endl;
    }else {
         cout << "Not enough money! You need "
         << ticketsPrice - budget << " leva." << endl;
    }

    return 0;
}
