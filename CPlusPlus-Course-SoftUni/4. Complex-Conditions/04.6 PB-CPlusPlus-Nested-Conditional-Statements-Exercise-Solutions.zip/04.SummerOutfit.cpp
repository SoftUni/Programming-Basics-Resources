#include<iostream>
#include<cmath>
using namespace std;

int main()
{
    int degrees;
    string type;

    cin >> degrees >> type;

    string shoes = "";
    string outfit = "";

    if(degrees >= 10 && degrees <= 18)
    {
        if(type == "Morning")
        {
            shoes = "Sneakers";
            outfit = "Sweatshirt";
        }
        else if(type == "Afternoon")
        {
            shoes = "Moccasins";
            outfit = "Shirt";
        }
        else if (type == "Evening")
        {
            shoes = "Moccasins";
            outfit = "Shirt";
        }
    }
    else if(degrees > 18 && degrees <= 24)
    {
        if(type == "Morning")
        {
            shoes = "Moccasins";
            outfit = "Shirt";
        }
        else if(type == "Afternoon")
        {
            shoes = "Sandals";
            outfit = "T-Shirt";
        }
        else if (type == "Evening")
        {
            shoes = "Moccasins";
            outfit = "Shirt";
        }
    }else {
        if(type == "Morning")
        {
            shoes = "Sandals";
            outfit = "T-Shirt";
        }
        else if(type == "Afternoon")
        {
            shoes = "Barefoot";
            outfit = "Swim Suit";
        }
        else if (type == "Evening")
        {
            shoes = "Moccasins";
            outfit = "Shirt";
        }

    }

    cout << "It's " << degrees << " degrees, get your " << outfit << " and " << shoes << ".";


    return 0;

}
