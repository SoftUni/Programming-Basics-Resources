#include<iostream>
#include<cmath>
using namespace std;

int main()
{

    int num1, num2;
    char operation;
    cin >> num1 >> num2 >> operation;

    string typeNumber = "";

    if(operation == '+'){
            int sum = num1 + num2;

            if(sum % 2 == 0){
                cout << num1 << " " << operation << " " << num2 << " = " <<
        sum << " - " << "even";
            }else {
                cout << num1 << " " << operation << " " << num2 << " = " <<
        sum << " - " << "odd";
            }


    }else  if(operation == '-'){
            int diff = num1 - num2;

            if(diff % 2 == 0){
                typeNumber = "even";
            }else {
                typeNumber = "odd";
            }

        cout << num1 << " " << operation << " " << num2 << " = " <<
        diff << " - " << typeNumber;
    }else if(operation == '*'){
            int product = num1 * num2;

            if(product % 2 == 0){
                typeNumber = "even";
            }else {
                typeNumber = "odd";
            }

        cout << num1 << " " << operation << " " << num2 << " = " <<
        product << " - " << typeNumber;
    }else if (operation == '/'){

        if(num2 == 0){
            cout << "Cannot divide " << num1 << " by zero";
        }else {
            double division = num1 * 1.0 / num2 ;
            cout.setf(ios::fixed);
            cout.precision(2);
            cout << num1 << " " << operation << " " << num2 << " = "
            << division;
        }

    }
    else if (operation == '%'){

        if(num2 == 0){
            cout << "Cannot divide " << num1 << " by zero";
        }else {
            int division = num1 % num2 ;
            cout.setf(ios::fixed);
            cout.precision(2);
            cout << num1 << " " << operation << " " << num2 << " = "
            << division;
        }
    }


    return 0;

}

