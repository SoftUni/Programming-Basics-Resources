#include<iostream>
#include<cmath>
using namespace std;

int main()
{

    string flowerType;
    int flowers, budget;
    cin >> flowerType >> flowers >> budget;

    double price = 0;

    if(flowerType == "Roses")
    {
        price = 5;
    }
    else if (flowerType == "Dahlias")
    {
        price = 3.80;
    }
    else if ( flowerType == "Tulips")
    {
        price = 2.80;
    }
    else if (flowerType == "Narcissus")
    {
        price = 3;
    }
    else if (flowerType == "Gladiolus")
    {
        price = 2.50;
    }

    double needMoney = flowers * price;

    if(flowers > 80 && flowerType == "Roses")
    {
        needMoney = needMoney - 0.10 * needMoney;
    }
    else if (flowers > 90 && flowerType == "Dahlias")
    {
        needMoney = needMoney - 0.15 * needMoney;
    }
    else if(flowers > 80 && flowerType == "Tulips")
    {
        needMoney = needMoney - 0.15 * needMoney;
    }
    else if(flowers < 120 && flowerType == "Narcissus")
    {
        needMoney = needMoney + 0.15 * needMoney;
    }
    else if (flowers < 80 && flowerType == "Gladiolus")
    {
        needMoney = needMoney + 0.20 * needMoney;
    }

    cout.setf(ios::fixed);
    cout.precision(2);

    if(needMoney <= budget){
        cout << "Hey, you have a great garden with " << flowers << " " <<
         flowerType << " and " << budget - needMoney << " leva left.";
    }else {
        cout << "Not enough money, you need " << needMoney - budget << " leva more.";
    }



    return 0;

}
