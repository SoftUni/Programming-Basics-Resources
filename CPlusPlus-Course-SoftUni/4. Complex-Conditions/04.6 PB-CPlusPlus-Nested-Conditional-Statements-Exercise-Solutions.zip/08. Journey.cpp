#include<iostream>
#include<cmath>
using namespace std;

int main()
{
    double budget;
    string season;
    cin >> budget >> season;

    string destination = "";
    string type = "";
    double price = 0;



    if(season == "summer"){
        type = "Camp";
    }else if (season == "winter"){
        type = "Hotel";

    }

    if(budget <= 100){
        destination = "Bulgaria";
        if(season == "summer"){
            price = 0.30 * budget;
        }else if (season == "winter"){
            price = 0.70 * budget;
        }
    }else if(budget <= 1000){
        destination = "Balkans";
        if(season ==  "summer"){
            price = 0.40 * budget;
        }else if (season == "winter"){
            price = 0.80 * budget;
        }

    }else if(budget > 1000){
       destination = "Europe";
       type = "Hotel";

       price = 0.90 * budget;
    }

    cout.setf(ios::fixed);
    cout.precision(2);

    cout << "Somewhere in " << destination << endl;
    cout << type << " - " << price;






    return 0;

}
