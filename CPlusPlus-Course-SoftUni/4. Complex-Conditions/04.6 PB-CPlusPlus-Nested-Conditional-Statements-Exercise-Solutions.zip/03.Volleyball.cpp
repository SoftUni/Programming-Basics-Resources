#include<iostream>
#include<cmath>
using namespace std;

int main()
{
   string type;
   int holidays, weekends;
   cin >> type >> holidays >> weekends;

   double saturdayGames = (48 - weekends) * 3 / 4.0;
   double holidayGames = holidays * 2.0 / 3;

   double totalGames = saturdayGames + weekends + holidayGames;

   if(type == "leap"){
    totalGames = totalGames + 0.15 * totalGames; //1.15 * totalGames
   }

   cout << floor(totalGames) << endl;

    return 0;

}
