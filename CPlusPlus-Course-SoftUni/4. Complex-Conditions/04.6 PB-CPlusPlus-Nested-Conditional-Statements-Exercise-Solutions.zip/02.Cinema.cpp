#include<iostream>
#include<string>
using namespace std;

int main()
{
  string type;
  int rows, columns;
  cin >> type >> rows >> columns;

  int allSits = rows * columns;
  // allSits * price

  double price = 0;

  if(type == "Premiere"){
    price = 12;
  }else if (type == "Normal"){
    price = 7.50;
  }else if(type == "Discount"){
    price = 5;
  }

  cout.setf(ios::fixed);
  cout.precision(2);
  double profit = allSits * price;
  cout << profit << " leva" << endl;

    return 0;

}
