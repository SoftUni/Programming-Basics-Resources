#include<iostream>
#include<string>
using namespace std;

int main()
{
  double x1, y1, x2, y2, x, y;
  cin >> x1 >> y1 >> x2 >> y2 >> x >> y;

  //����� ��������
  bool firstCheck = (x == x1) || (x == x2);
  bool secondCheck = (y >= y1) && (y <= y2);
  bool check1 = firstCheck && secondCheck;

  //����� ��������
  bool thirdCheck = (y == y1) || (y == y2);
  bool forthCheck = (x >= x1) && (x <= x2);
  bool check2 = thirdCheck && forthCheck;

  if(check1 || check2){
    cout << "Border";
  }else {
    cout << "Inside / Outside";
  }

    return 0;

}
