#include<iostream>
#include<string>
using namespace std;

int main()
{

    int n;
    cin >> n;

    int group1 = 0, group2 = 0, group3 = 0;

    for(int i = 0; i < n ; i++){

        int number;
        cin >> number;

        if(number % 2 == 0){
                group1++;
        }
        if(number % 3 == 0){
                group2++;
        }
        if(number % 4 == 0){
            group3++;
        }
    }

    double percent1 = group1 * 1.0 / n * 100;
    double percent2 = group2 * 1.0/ n * 100;
    double percent3 = group3 * 1.0/ n * 100;

    cout.setf(ios::fixed);
    cout.precision(2);

    cout << percent1 << "%" << endl;
    cout << percent2 << "%" << endl;
    cout << percent3 << "%" << endl;



    return 0;
}

