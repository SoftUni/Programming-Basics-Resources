#include<iostream>
#include<string>
#include<cmath>
using namespace std;

int main()
{

    int budget;
    cin >> budget;

    int items;
    cin >> items;

    int  spendMoney = 0;


    for(int i = 0; i < items ; i++)
    {
        string item;
        cin >> item;

        if(item == "hoodie")
        {
            spendMoney += 30;

        }
        else if(item == "keychain")
        {
            spendMoney += 4;
        }
        else if(item == "T-shirt")
        {
            spendMoney += 20;
        }
        else if(item == "flag")
        {
            spendMoney += 15;
        }
        else if(item == "sticker")
        {
            spendMoney += 1;
        }

    }


    if(budget >= spendMoney){

        cout << "You bought " << items
        << " items and left with " << budget - spendMoney
        << " lv." << endl;

    }else {

        cout << "Not enough money, you need "
        << spendMoney - budget  << " more lv." << endl;
    }



    return 0;
}
