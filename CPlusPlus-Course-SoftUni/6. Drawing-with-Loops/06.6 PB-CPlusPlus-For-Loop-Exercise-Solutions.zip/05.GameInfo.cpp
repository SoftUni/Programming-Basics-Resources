#include<iostream>
#include<string>
#include<cmath>
using namespace std;

int main()
{
    string teamName;
    cin >> teamName;

    int matches;
    cin >> matches;

    int totalTime = 0;
    int countOvertime = 0;
    int countPenalties = 0;


    for (int i = 0; i < matches ; i++){
            int time;
            cin >> time;

            totalTime += time;

            if(time > 90 && time <= 120){
                countOvertime++;
            }else if(time > 120){
                countPenalties++;
            }

    }

    cout.setf(ios::fixed);
    cout.precision(2);

    cout << teamName << " has played " << totalTime << " minutes. Average minutes per game: "
    << totalTime * 1.0 / matches << endl;
    cout << "Games with penalties: " << countPenalties << endl;
    cout << "Games with additional time: " << countOvertime << endl;




    return 0;
}

