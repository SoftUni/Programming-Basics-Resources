#include<iostream>
#include<string>
using namespace std;

int main()
{

    int computers;
    cin >> computers;

    int totalSales = 0;
    int totalRating = 0;

    for (int i = 0; i < computers; i++){

            int number;
            cin >> number;

            int rating = number % 10;
            int posibleSales = number / 10;

            double sales = 0;

            if(rating == 2){
                sales = 0.00 * posibleSales;
            }else if(rating == 3){
                sales = 0.50 * posibleSales;
            }else if (rating == 4){
                sales = 0.70 * posibleSales;
            }else if(rating == 5){
                sales = 0.85 * posibleSales;
            }else if(rating == 6){
                sales = 1.00 * posibleSales;
            }

            totalSales += sales;
            totalRating += rating;

    }

    cout.setf(ios::fixed);
    cout.precision(2);

    cout << totalSales * 1.0 << endl;
    cout << totalRating * 1.0 / computers << endl;



    return 0;
}
