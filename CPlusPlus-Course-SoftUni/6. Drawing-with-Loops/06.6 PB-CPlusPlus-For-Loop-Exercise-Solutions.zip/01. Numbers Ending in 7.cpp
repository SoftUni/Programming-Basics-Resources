#include <iostream>
#include <string>

using namespace std;

int main()
{

    for(int i = 7 ; i <= 997; i += 10)
    {
        cout << i << endl;
    }

    return 0;
}
