#include<iostream>
#include<string>

using namespace std;

int main()
{
    string searchBook;
    getline(cin, searchBook);

    int capacity;
    cin >> capacity;

    cin.ignore();

    string bookInLibrary;
    getline(cin, bookInLibrary);

    int checkBooks = 0;

    bool isFound = false;

    while(searchBook != bookInLibrary || capacity >= checkBooks)
    {

        if(searchBook == bookInLibrary)
        {
            isFound = true;
            break;
        }
        if(checkBooks >= capacity)
        {
            isFound = false;
            break;
        }
        getline(cin, bookInLibrary);
        checkBooks ++;
    }

    if(isFound)
    {
        cout << "You checked "<< checkBooks <<" books and found it." << endl;

    }
    else
    {
        cout << "The book you search is not here!" << endl <<
             "You checked " << checkBooks << " books." << endl;
    }

    return 0;
}
