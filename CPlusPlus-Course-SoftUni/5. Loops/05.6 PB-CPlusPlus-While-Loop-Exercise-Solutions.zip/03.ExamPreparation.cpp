#include<iostream>
#include<string>

using namespace std;

int main()
{
    int maxPoorGrades;
    cin >> maxPoorGrades;

    cin.ignore();

    string task;
    getline(cin, task);
     int countPoorGrade = 0;

     double sum = 0;
     int counter = 0;
     string lastProblem = "";

    while(task != "Enough"){

        int grade;
        cin >> grade;
        sum += grade;
        counter++;

        if(grade <= 4){

            countPoorGrade++;
        }
         if(countPoorGrade == maxPoorGrades){

            cout << "You need a break, " << countPoorGrade << " poor grades." << endl;
           return 0;
         }

         lastProblem = task;

         cin.ignore();
         getline(cin, task);

    }

    cout.setf(ios::fixed);
    cout.precision(2);

    cout << "Average score: " << sum / counter << endl;

    cout.precision(0);
    cout << "Number of problems: " << counter << endl;
    cout << "Last problem: " << lastProblem << endl;

    return 0;
}
