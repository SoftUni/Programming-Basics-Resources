#include<iostream>
#include<string>

using namespace std;

int main()
{
    double moneyLeva;
    cin >> moneyLeva;
     int money = moneyLeva * 100;

    int countCoins = 0;



    while(money > 0){

            if(money >= 200){
                countCoins++;
                money = money - 200;

            }else if(money >= 100){
                countCoins++;
                money = money - 100;
            }else if(money >= 50){
                countCoins++;
                money = money - 50;
            }else if(money >= 20){
                countCoins++;
                money = money - 20;
            }else if(money >= 10){
                countCoins++;
                money = money - 10;
            }else if(money >= 5){
                countCoins++;
                money = money - 5;
            }else if(money >= 2){
                countCoins++;
                money = money - 2;
            }else if(money >= 1){
                countCoins++;
                money = money - 1;
            }

    }

    cout << countCoins << endl;

    return 0;
}
