#include<iostream>
#include<string>

using namespace std;

int main()
{

    double priceTrip, money;
    cin >> priceTrip >> money;

    int daysInSpend = 0;
    int countDays = 0;

    while(true){
        string action;
        cin >> action;
        double sum;
        cin >> sum;
        countDays++;

        if(action == "save"){
                daysInSpend = 0;
            money = money + sum;
        }else if(action == "spend"){
            daysInSpend++;
            money = money - sum;
            if(money < 0){
                money = 0;
            }
        }

        if(daysInSpend == 5){
            cout << "You can't save the money." << endl;
            cout << countDays << endl;
            break;
        }

        if(money >= priceTrip){

            cout << "You saved the money for " << countDays << " days." << endl;
            break;
        }


    }
    return 0;
}
