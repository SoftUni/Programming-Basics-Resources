#include <iostream>
#include <string>

using namespace std;

int main(){

    string studentName;

    cin >> studentName;

    //We set the class counter to 1 since we can only start from first grade
    int gradesCounter = 1;
    //We also need counter for each failed grade
    int failedGradeCounter = 0;
    //We want to keep all the marks the student got
    double totalGrades = 0;

    //We can go only to 12-th grade
    while(gradesCounter <= 12 && failedGradeCounter < 2){
        //Each grade we read the mark
        double grade;
        cin >> grade;
        //If the mark is not less than 4.00
        if(grade >= 4.00){
            //We move the student to the next class
            gradesCounter++;
            //And add the current class mark
            totalGrades += grade;
        }else{
            failedGradeCounter++;
        }
    }
    //We check for the two different possible outputs
    if(failedGradeCounter < 2){
        //We set the output format
        cout.setf(ios::fixed);
        cout.precision(2);
        //Since we increase the grade counter each time a student passes a grade
        //at the end it will be equal to 13 but that is not a valid grade to be at
        //so we decrease it by one
        --gradesCounter;
        //We divide the total sum of the marks by the grades or by 12 and print the output
        cout << studentName << " graduated. Average grade: " << totalGrades / gradesCounter << endl;
    }else{
        cout << studentName << " has been excluded at " << gradesCounter << " grade" << endl;
    }

    return 0;
}
