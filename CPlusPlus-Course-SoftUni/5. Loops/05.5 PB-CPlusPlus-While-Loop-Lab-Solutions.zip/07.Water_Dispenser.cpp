#include <iostream>
#include <string>

using namespace std;

int main(){

    int volume;

    cin >> volume;

    string preassure;
    cin >> preassure;

    int pushesCount = 0;

    //We will decrease the volume each time a button is pressed
    //if the volume goes not greater than zero there are two possibilities
    //first the glass may be full or the water has overflown from the glass
    while (volume > 0){
        pushesCount++;
        if(preassure == "Easy"){
           volume -= 50;
        }else if(preassure == "Medium"){
           volume -= 100;
        }else{
           volume -= 200;
        }

        cin >> preassure;
    }

    //If the volume is less than zero then we print the spilled water
    if(volume < 0){
        cout << volume * -1 << "ml has been spilled." << endl;
    }
    //Otherwise we print the counter
    else{
        cout << "The dispenser has been tapped " << pushesCount << " times." << endl;
    }

    return 0;
}
