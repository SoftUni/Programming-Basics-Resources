#include <iostream>

using namespace std;

int main(){

    int number;

    cin >> number;

    //This loop will continue until the boolean condition returns false
    //It will only be false if the number is in range [1...100]
    while(number < 1 || number > 100){
        //On each iteration we print message that the number is invalid
        cout << "Invalid number!" << endl;
        //Then we read from the console again
        cin >> number;
    }

    //At the end we print the output
    cout << "The number is: " << number << endl;


    return 0;
}
