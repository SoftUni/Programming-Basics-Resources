#include <iostream>
#include <string>

using namespace std;

int main(){

    string input;

    //Here we need to use getline() function since we can have two words on a single line
    getline(cin, input);

    //We set initial steps counter to zero
    int totalSteps = 0;

    //We two conditions for the loop to stop the first one is
    //if the input is equal to "Going home" and the other if the steps
    //are equal or greater to 10000
    while(input != "Going home" && totalSteps < 10000){
        //If we enter the loop we can parse the string to int and add
        //it's value to the total count of steps
        totalSteps += stoi(input);
        //Again we read the input data inside the loop otherwise it will be an endless loop
        getline(cin, input);
    }

    //If the reason we exited the loop is that the input is equal to "Going home"
    if(input == "Going home"){
        //We have to read the steps on the way back
        getline(cin, input);
        //Add them to the total count of steps
        totalSteps += stoi(input);
            //Check if target of 10000 is reached
            if(totalSteps >= 10000){
                cout << "Goal reached! Good job!" << endl;
            }else{
                //Otherwise the target was not reached and so we print
                //the value of steps remaining to reach the goal
                cout << 10000 - totalSteps << " more steps to reach goal." << endl;
            }
    }else{
        //If the program exited the loop because the count of steps is not less
        //than 10000 then we simply print the following message
        cout << "Goal reached! Good job!" << endl;
    }

    return 0;
}
