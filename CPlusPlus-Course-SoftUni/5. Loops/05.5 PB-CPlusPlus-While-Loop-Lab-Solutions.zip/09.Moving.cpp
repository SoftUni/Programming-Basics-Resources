#include <iostream>

using namespace std;

int main(){

    int width, length, height;

    cin >> width >> length >> height;

    string command;

    cin >> command;

    //Calculate the volume of the apartment
    int volume = width * length * height;

    //If we read command "Done" we need to exit the loop
    while(command != "Done"){

        //On each iteration we decrease the volume
        volume -= stoi(command);

        //If the volume goes below zero we have to break the loop
        if(volume < 0){
            break;
        }

        //Update the input
        cin >> command;
    }

    //Simple checks for the two possible outputs
    if(volume < 0){
        cout << "No more free space! You need " << volume * -1 << " Cubic meters more." << endl;
    }else{
        cout << volume << " Cubic meters left." << endl;
    }

    return 0;
}
