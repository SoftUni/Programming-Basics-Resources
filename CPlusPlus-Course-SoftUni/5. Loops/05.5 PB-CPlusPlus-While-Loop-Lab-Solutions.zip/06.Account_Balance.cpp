#include <iostream>

using namespace std;

int main(){

    int operationsCount;

    cin >> operationsCount;

    double balance = 0;

    cout.setf(ios::fixed);
    cout.precision(2);

    //Each time we read amount we will decrease operations count by one
    while(operationsCount > 0){
        double amount;
        cin >> amount;

        if(amount < 0){
                cout << "Invalid operation!" << endl;
            break;
        }else{
            balance += amount;
            cout << "Increase: " << amount << endl;
        }
        //Decrease operations count this is postfix operator
        //Try to do it with prefix
        //What is the difference between both operators
        //If you use prefix operator here will the program run differently
        operationsCount--;
    }

    cout << "Total: " << balance << endl;

    return 0;
}
