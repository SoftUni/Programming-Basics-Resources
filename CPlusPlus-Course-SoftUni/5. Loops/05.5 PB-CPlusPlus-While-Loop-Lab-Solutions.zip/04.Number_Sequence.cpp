#include <iostream>

using namespace std;

int main(){

    string input;

    //Read the input as a string
    cin >> input;

    //Set variables that will keep the min and max values

    //When searching for max value
    //set the variable value to the minimum possible
    int maxNum = INT_MIN;
    //Do the opposite for the min value
    int minNum = INT_MAX;

    //The loop will go as long as we don\t read "END"
    while(input != "END"){

        //We can use string to int function "stoi()" to parse the string as an integer
        //we can be sure that the string is with integer format since if it's "END"
        //the program will not execute this code
        //Be careful when using this function anything different from integer inside the string
        //will cause runtime error
        int currentNumber = stoi(input);

        //If the number is greater than the current maxNum we assign new value
        //to our maxNum variable
        if(currentNumber > maxNum){
            maxNum = currentNumber;
        }

        //The same as for the maxNum but with the lesser operator
        if(currentNumber < minNum){
            minNum = currentNumber;
        }

        //Each iteration we read the new input
        cin >> input;
    }

    //Print the output
    cout << "Max number: " << maxNum << endl;
    cout << "Min number: " << minNum << endl;

    return 0;
}
