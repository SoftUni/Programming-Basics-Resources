#include <iostream>

using namespace std;

int main(){

    int number;

    cin >> number;

    //Set counter with initial value 0
    //since we have multiplication here
    int counter = 0;

    //We want to do calculations only if the counter is not greater than the number
    while (counter <= number){
        //We do the calculation here
        counter = 2 * counter + 1;
        //We check if we should print the value
        if(counter <= number){
            cout << counter << endl;
        }
    }

    return 0;
}
